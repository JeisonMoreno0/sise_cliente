import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-info-academica',
  templateUrl: './info-academica.page.html',
  styleUrls: ['./info-academica.page.scss'],
})
export class InfoAcademicaPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
