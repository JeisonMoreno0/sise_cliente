import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-localizacion',
  templateUrl: './localizacion.page.html',
  styleUrls: ['./localizacion.page.scss'],
})
export class LocalizacionPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
